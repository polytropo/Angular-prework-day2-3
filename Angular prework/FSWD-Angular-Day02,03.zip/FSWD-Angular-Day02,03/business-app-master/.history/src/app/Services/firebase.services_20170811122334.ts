import {Injectable} from '@angular/core';
import {AngularFire, FirebaseListObservable} from 'angularfire';